const namaKaryawan = "Budi Santoso";
const gajiPokok = 5000000;
const tunjangan = 1000000;
const bonus = 500000;

const hitungGaji = (pokok, tunjangan, bonus) => {
  let totalPendapatan = pokok + tunjangan + bonus;
  let potongan = totalPendapatan * 0.05;
  let gajiBersih = totalPendapatan - potongan;

  return { totalPendapatan, potongan, gajiBersih };
};

let hasil = hitungGaji(gajiPokok, tunjangan, bonus);

console.log(`
Nama Karyawan    : ${namaKaryawan}
Gaji Pokok       : Rp${gajiPokok.toLocaleString("id-ID")}
Tunjangan        : Rp${tunjangan.toLocaleString("id-ID")}
Bonus            : Rp${bonus.toLocaleString("id-ID")}
Total Pendapatan : Rp${hasil.totalPendapatan.toLocaleString("id-ID")}
Potongan (5%)    : Rp${hasil.potongan.toLocaleString("id-ID")}
Gaji Bersih      : Rp${hasil.gajiBersih.toLocaleString("id-ID")}
`);